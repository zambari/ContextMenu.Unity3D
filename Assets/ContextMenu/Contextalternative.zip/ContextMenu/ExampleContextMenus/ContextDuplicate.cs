﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using zUI;

public class ContextDuplicate : MonoBehaviour, IContextMenuRequester
{
    public bool wantsMenu
    {
        get
        {
            return true;
        }
    }

    public void DrawMenu(PrefabProvider prefabs, RectTransform parent, IContextMenuHandler handler)
    {
        // var b1 = prefabs.GetGameObject(parent, ContextMenuHandler.contextItemName, "Duplicate");
        //   var b2 = prefabs.GetGameObject(parent, ContextMenuHandler.contextItemName, "Remove");
        prefabs.GetButton(parent, "Duplicate").onClick.AddListener(() =>
          {
              var instance = GameObject.Instantiate(gameObject);
              TransformGizmo.instance.ClearAndAddTarget(instance.transform);
              handler.CloseMenu();

          });
         prefabs.GetButton(parent, "Remove").onClick.AddListener(() =>
         {
             handler.CloseMenu();
             Destroy(gameObject);
             TransformGizmo.instance.ClearTargets();
         });
    }

    public string GetMenuName()
    {
        return "dup";
    }
}
