﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
namespace zUI
{
    public class ContextTriggerUnityEvent : MonoBehaviour, IContextMenuRequester
    {
        [System.Serializable]
        public class NamedEvent
        {
            public string name;
            public UnityEvent eventToCall;
        }
        public NamedEvent[] events = new NamedEvent[3];
        public bool wantsMenu { get { return enabled; } }
        public string GetMenuName()
        {
            return name;
        }
        public void DrawMenu(PrefabProvider prefabs, RectTransform target, IContextMenuHandler handler)
        {
            for (int i = 0; i < events.Length; i++)
            {
                NamedEvent thisEvent = events[i];
                var button = prefabs.GetButton(target, thisEvent.name);
                button.onClick.AddListener(() =>   // click handler
                 {
                     thisEvent.eventToCall.Invoke();
                     handler.CloseMenu();
                 }
                );
            }
        }
          void Reset()
        {
            events = new NamedEvent[3];
            for (int i = 0; i < events.Length; i++)
            {
                events[i] = new NamedEvent();
                events[i].name = zExt.RandomString(4);
            }
        }

    }
}