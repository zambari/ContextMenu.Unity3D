﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
namespace zUI
{

    public class ContextReparenter : MonoBehaviour, IContextMenuRequester
    {
        public bool wantsMenu
        {
            get
            {
                return true;
            }
        }
        static Transform pickedChild;
        static Transform pickedParent;
        public void DrawMenu(PrefabProvider prefabs, RectTransform parent, IContextMenuHandler handler)
        {
            prefabs.GetButton(parent, "Pick As Child").onClick.AddListener(() =>
            {
                pickedChild = transform;
                handler.CloseMenu();

            });
            prefabs.GetButton(parent, "Pick As Parent").onClick.AddListener(() =>
            {
                handler.CloseMenu();
                pickedParent = transform;

            });
            if (pickedChild != null)
            {
                prefabs.GetButton(parent, "Paste Parenter here").onClick.AddListener(() =>
               {
                   pickedChild.SetParent(transform);
                   handler.CloseMenu();

               });
                prefabs.GetButton(parent, "Paste Parenter here And Move").onClick.AddListener(() =>
             {
                 pickedChild.SetParent(transform);
                 pickedChild.localPosition = Vector3.zero;
                 handler.CloseMenu();

             });
            }
            if (pickedParent != null)
            {

               prefabs.GetButton(parent, "Paste as child here").onClick.AddListener(() =>
                {
                    transform.SetParent(pickedChild);
                    handler.CloseMenu();
                });

                 prefabs.GetButton(parent, "Paste as child here and M|ove").onClick.AddListener(() =>
                {
                    transform.SetParent(pickedChild);
                    transform.localPosition = Vector3.zero;
                    handler.CloseMenu();
                });
            }
        }
        public string GetMenuName()
        {
            return "dup";
        }
    }
}