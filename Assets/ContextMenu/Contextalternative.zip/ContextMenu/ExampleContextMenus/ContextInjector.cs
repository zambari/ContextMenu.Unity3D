﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ContextInjector : MonoBehaviour, IContextMenuRequester
{
    public List<NameAndCommand> commands = new List<NameAndCommand>();

    public bool wantsMenu
    {
        get
        {
            return true;
        }
    }

    public void AddCommand(string _name, System.Action _command)
    {
        if (commands==null) commands = new List<NameAndCommand>();
        commands.Add(new NameAndCommand() { name = _name, command = _command });
    }

    public void DrawMenu(PrefabProvider prefabs, RectTransform parent, IContextMenuHandler handler)
    {
        for (int i = 0; i < commands.Count; i++)
        {
            var button = prefabs.GetButton(parent, commands[i].name);
            button.onClick.AddListener(() => commands[i].command());
        }
    }

    public string GetMenuName()
    {
        return "Favs";//null;
    }

    public class NameAndCommand
    {
        public System.Action command;
        public string name;

    }

}
