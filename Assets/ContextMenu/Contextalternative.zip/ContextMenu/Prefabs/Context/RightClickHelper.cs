﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/*
   public void RequestMenu(out List<string>labels,out  List<UnityAction> callbacks)
    {
        labels=new  List<string>();
        callbacks=new List<UnityAction>();
        for (int i=0;i<3;i++)
        {
            labels.Add("cbk "+i);
            int k=i;
            callbacks.Add(()=>Debug.Log("callback "+k));
        }*/
namespace zUI
{
    public class RightClickHelper : MonoBehaviour
    {
        public ContextMenu contextMenu;

        public List<RaycastResult> RaycastMouse()
        {

            PointerEventData pointerData = new PointerEventData(EventSystem.current)
            {
                pointerId = -1,
            };

            pointerData.position = Input.mousePosition;

            List<RaycastResult> results = new List<RaycastResult>();
            EventSystem.current.RaycastAll(pointerData, results);
            return results;
        }
        List<RaycastResult> list;
        void Update()
        {
            if (Input.GetMouseButtonDown(1))
            {
                if (contextMenu.menuVisible)
                {
                    contextMenu.gameObject.Hide();
                    Debug.Log("hiding");
                    return;
                }
                list = RaycastMouse();
                foreach (var i in list)
                {
                    var c = i.gameObject.GetComponent<IContextMenu>();
                    if (c != null)
                    {
                        contextMenu.RequestMenu(c);
                        contextMenu.transform.position = Input.mousePosition; //?
                        return;
                    }

                    var r = i.gameObject.GetComponent<IRightClickHandler>();
                    if (r != null)
                    {
                        r.OnRightClick();
                        return;
                    }
                }

            }
        }
    }

}