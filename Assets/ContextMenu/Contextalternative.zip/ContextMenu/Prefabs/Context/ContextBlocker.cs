﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ContextBlocker : MonoBehaviour, IPointerClickHandler
{
    public GameObject contextMenu;
    public void OnPointerClick(PointerEventData e)
    {
        if (contextMenu != null) contextMenu.Hide();

    }
}
