﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace zUI
{
    public class ContextMenu : ListPopulator


    {
        public bool menuVisible;
        public GameObject contextBlocker;
        // Start is called before the first frame update
        void OnEnable()
        {
            if (contextBlocker != null) contextBlocker.SetActive(true);
            menuVisible = true;
        }
        void OnDisable()
        {
            if (contextBlocker != null) contextBlocker.SetActive(false);
            menuVisible = false;
        }
        public void RequestMenu(IContextMenu rquester)
        {
            var labels = new List<string>();
            var callbacks = new List<UnityAction>();
            rquester.RequestMenu(out labels, out callbacks);
            if (labels.Count != callbacks.Count)
            {
                Debug.Log("different counts returned");
                return;
            }
            SetListSize(labels.Count);
            for (int i = 0; i < labels.Count; i++)
            {
                items[i].SetLabel(labels[i]);
                if (callbacks.Count < i && callbacks[i] != null)
                    items[i].button.onClick.AddListener(callbacks[i]);
                items[i].button.onClick.AddListener(CloseMenu);
            }
            gameObject.Show();
        }
        void CloseMenu()
        {
            gameObject.Hide();
            Debug.Log("closingmneu");
        }
    }


}
