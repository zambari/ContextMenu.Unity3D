﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
namespace zUI
{
    public class ContexUnityEventsester : MonoBehaviour, IContextMenuRequester
    {
        [System.Serializable]
        public class NamedEvent
        {
            public string name;
            public UnityEvent eventToCall;
        }
        public NamedEvent[] events = new NamedEvent[3];

        public bool wantsMenu { get { return enabled; } }

        public string GetMenuName() { return name; }

        public void DrawMenu(PrefabProvider prefabs, RectTransform target, IContextMenuHandler handler)
        {
            //     string prefabName=handler.GetPrefabName();
            for (int i = 0; i < events.Length; i++)
            {
                NamedEvent thisEvent = events[i];
                prefabs.GetButton(target, thisEvent.name).onClick.AddListener(() =>
                  {
                      Debug.Log("clicked on event " + thisEvent.name);
                      thisEvent.eventToCall.Invoke();
                      handler.CloseMenu();
                  }
                );
            }
        }

    }
}

[System.Obsolete("i think icontexmenu is better")]
public interface IContextMenuRequester
{
    // return true if you want your menu to appear in this context
    bool wantsMenu { get; }
    // return name for header
    string GetMenuName();
    // draw your menu here, context will be provided by ContextMenuHandler
    void DrawMenu(PrefabProvider prefabs, RectTransform parent, IContextMenuHandler handler);

    GameObject gameObject { get; }
    string name { get; }

}


public interface IContextMenuHandler
{
    //string GetPrefabName();
    void CloseMenu();

}