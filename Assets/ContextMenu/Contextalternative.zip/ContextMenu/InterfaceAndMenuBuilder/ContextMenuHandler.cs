﻿using System.Collections;
using System.Collections.Generic;
using LayoutPanelDependencies;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Z;

namespace zUI
{
    [RequireComponent(typeof(AttachRect))]
    public class ContextMenuHandler : MonoBehaviour, IContextMenuHandler, IRequestInitLate
    {

        public DrawInspectorBg draw;
        public Button blanker;
        public RectTransform contextContent;
        List<GameObject> createdItems = new List<GameObject>();
       public bool contexMenuVisible;
        bool wasInit;

        List<RaycastResult> list;
        PrefabProvider prefabs;
        public bool usePhysicsRaycast = true;
        public LayerMask layerMask;
        RaycastHit hit;
        public Camera editorCamera;
        Transform hitTransform;
        Vector3 relativePonit;
        AttachRect attachRect;
        public bool dynamicFollowOfPhysicsObjects = true;
        void Awake()
        {
           
        }
        void Start()
        {
            Init(this);
            attachRect = gameObject.AddOrGetComponent<AttachRect>();
        }
        public void CloseMenu()
        {
            Debug.Log("closing");
            createdItems = new List<GameObject>();
            for (int i = 0; i < contextContent.childCount; i++)
                createdItems.Add(contextContent.GetChild(i).gameObject);
            blanker.gameObject.SetActive(false);
            contextContent.gameObject.SetActive(false);
            foreach (var c in createdItems)
            {
                if (c != null) Destroy(c);
            }
            createdItems = new List<GameObject>();
            contexMenuVisible = false;
            attachRect.enabled = false;
        }
        void ShowMenu(Vector2 position)
        {
            if (contexMenuVisible)
            {
                Debug.Log("is shown,  closing");
                CloseMenu();
                return;
            }
            Debug.Log("showing");
            blanker.gameObject.SetActive(true);
            contextContent.gameObject.SetActive(true);
    gameObject.SetActive(true);
            contextContent.position = position;
            contexMenuVisible = true;
        }
        public List<RaycastResult> RaycastMouse()
        {
            PointerEventData pointerData = new PointerEventData(EventSystem.current)
            {
                pointerId = -1,
            };
            pointerData.position = Input.mousePosition;
            List<RaycastResult> results = new List<RaycastResult>();
            EventSystem.current.RaycastAll(pointerData, results);
            return results;
        }
        void DrawMenuFor(IContextMenuRequester requester)
        {
            ShowMenu(Input.mousePosition);
            string menuName = requester.GetMenuName();
            if (!string.IsNullOrEmpty(menuName))
                prefabs.GetHeader(contextContent, menuName);
            requester.DrawMenu(prefabs, contextContent, this);

        }
        bool CheckUIRaycast()
        {
            list = RaycastMouse();
            for (int i = 0; i < list.Count; i++)
            {
                var requesters = list[i].gameObject.GetComponentsInChildren<IContextMenuRequester>();
                if (requesters.Length > 0)
                {
                    blanker.gameObject.SetActive(true);
                    contextContent.gameObject.SetActive(true);
                    attachRect.enabled = false;
                    foreach (var r in requesters)
                        DrawMenuFor(r);
                }
            }
            return list.Count > 0;
        }

        IEnumerator AttachAimer(Transform source, Vector3 relativePoint)
        {
            while (true)
            {
                attachRect.targetPoint = source.TransformPoint(relativePonit);
                yield return null;
            }

        }
        void CheckPhysicsRaycast()
        {

            Debug.Log("doing physics raycast");
            var ray = editorCamera.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out hit, 30, layerMask))
            {
                var requesters = hit.collider.GetComponentsInChildren<IContextMenuRequester>();
                ShowMenu(new Vector2(Screen.width / 2, Screen.height / 2));
                foreach (var requester in requesters)
                    if (requester != null && requester.wantsMenu)
                    {
                        hitTransform = hit.collider.transform;
                        relativePonit = hitTransform.InverseTransformPoint(hit.point + hit.normal * .2f);
                        DrawMenuFor(requester);
                        attachRect.enabled = true;
                        //   if (isActiveAndEnabled)
                        //   {
                        if (dynamicFollowOfPhysicsObjects)
                            StartCoroutine(AttachAimer(hitTransform, relativePonit));
                        else
                            attachRect.targetPoint = hit.point;
                        //   }
                    }
            }
        }
        IEnumerator RightClickWatch()
        {
            while (true)
            {
                if (Input.GetMouseButtonDown(1))
                {
                    if (contexMenuVisible)
                        CloseMenu();
                    else
                    {
                        if (!CheckUIRaycast() && usePhysicsRaycast)
                            CheckPhysicsRaycast();
                    }
                }
                yield return null;
            }
        }


        public void Init(MonoBehaviour awakenSource)
        {

            if (editorCamera == null) usePhysicsRaycast = false;
            if (wasInit) return;
            if (blanker != null)
            {
                blanker.onClick.AddListener(CloseMenu);
                blanker.gameObject.SetActive(false);
                contexMenuVisible = false;
            }
            attachRect =  gameObject.AddOrGetComponent<AttachRect>();
            attachRect.enabled = false;
            if (prefabs == null) prefabs = PrefabProvider.Get(this);
            wasInit = true;
            awakenSource.StartCoroutine(RightClickWatch());
        }
    }
}