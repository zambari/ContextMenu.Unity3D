﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using Z;
using zUI;
public class ContextTester : MonoBehaviour, IContextMenu
{

    public void RequestMenu(out List<string> labels, out List<UnityAction> callbacks)
    {
        Debug.Log("menu req");
        labels = new List<string>() { " a", "b", "c" };
        callbacks = new List<UnityAction>() { null, null, null };
    }
}
